package Atividade1;

public class ClasseRunnable implements Runnable{

    //Métodos Override
    @Override
    public void run(){
        System.out.println("Minha primeira thread");
    }

}
